# Brief — Design de l'interface — Start And Shift (version finale)

## Le produit

Un entrepreneur/solopreneur arrive sans compte, répond à un questionnaire de 10 étapes, reçoit gratuitement une stratégie de com/vente complète générée par IA, puis peut commander en 1 clic des créas (posts, affiches, vidéos, motion) produites par une équipe créative + IA, à un tarif accessible aux petites structures.

**Positionnement à porter dans le design :** *"La stratégie ET l'exécution, pensées pour les indépendants et petites structures — pas pour les grandes équipes marketing."* Simplicité radicale : un écran, une action à la fois. Ton rassurant et honnête, jamais de jargon.

**Discours sur l'IA :** transparence discrète — "l'IA prépare, nos créatifs finalisent et vérifient" — sans en faire l'argument de vente principal. Prévoir une réponse honnête toute prête si un client demande explicitement comment ça fonctionne. Le fait qu'un seul créatif (Jean Eudes) traite tout au lancement reste interne, non communiqué aux utilisateurs.

## Cible et contexte d'usage

- Commerçants vendant via WhatsApp, lives TikTok, Marketplace ; entrepreneurs, solopreneurs, jeunes startups, PME, community managers freelances gérant plusieurs clients.
- Marchés : Togo au lancement, puis Afrique francophone, puis international.
- Conception mobile-first pour bas débit : Android entrée de gamme, réseau 3G instable, pages légères (<500 Ko), illustrations SVG plutôt que photos lourdes, pas d'autoplay vidéo, sauvegarde locale des réponses du questionnaire.

## Identité visuelle

- Logo et couleurs de la charte Start And Shift conservés (Bleu Start, Orange Shift, Encre, police Start Shift Sans).
- L'univers visuel de l'app (illustrations, composants) est redessiné, pas simplement recyclé depuis la charte existante.
- Illustrations SVG légères pour l'interface ; vraies photos réservées aux preuves sociales et au portfolio.
- Mode sombre : prévu en phase 2, non prioritaire au lancement.
- Animations sobres, un seul moment travaillé : l'écran de chargement où la stratégie "se construit" visuellement.
- Références : Wave, Typeform, Duolingo, Fiverr.

## Modèle économique — abonnement à 3 paliers

Abonnement uniquement, pas de paiement à l'unité pour les abonnés payants. Paliers renommés **Gratuit**, **Pro**, **Max**.

**Tarifs de référence marché à Lomé** (base de calcul) : créa statique simple 5 000 FCFA, vidéo courte 15-30 s 10 000 FCFA, motion design 15 000 FCFA. Marge visée sur les abonnements : 60 %.

### Gratuit
- Accès à la stratégie complète dès le départ (résumé "En clair" + détail pro), sans restriction.
- 1 créa offerte une seule fois, téléchargement inclus.
- Au-delà : créas supplémentaires payées à l'unité par crédit, au tarif marché (5 000 FCFA la créa statique).
- Pas de régénération de stratégie.

### Pro — 9 900 FCFA / mois
- 3 créas statiques incluses par mois.
- 1 régénération de stratégie par mois.
- Multi-marques activé (plusieurs profils de marque par compte — utile pour les community managers freelances).

### Max — 24 900 FCFA / mois
- 6 créas incluses par mois (mix : 5 statiques + 1 vidéo courte).
- 3 régénérations de stratégie par mois.
- Multi-marques inclus.

**Hypothèse de travail pour dimensionner la charge et la rentabilité :** 100 abonnés à 6 mois, répartis 60 % Gratuit, 30 % Pro, 10 % Max — soit environ 150 créas/mois à produire dans ce scénario, cohérent avec une production solo au lancement.

**Garantie :** remboursement du premier mois d'abonnement si insatisfait, après usage des révisions incluses.

**Facturation :** prix visibles avant connexion (page Tarifs publique). Factures PDF automatiques avec numérotation. Résiliation en 1 clic. Créas non utilisées reportées une fois sur le mois suivant.

## Fonctionnement des créas

- **Types au lancement :** créas statiques + vidéos courtes (15-30 s). Motion design plus complexe prévu en phase 2.
- **Délais indicatifs** (à ajuster selon la capacité réelle) : post/statut 24h, carrousel 48h, affiche 48-72h, vidéo courte 3-5 jours, motion 5-7 jours (phase 2). Option express : +50 %.
- **Révisions :** 2 révisions incluses par créa, livrées sous 24h chacune. Une révision doit respecter le brief initial ; tout changement de concept devient une nouvelle demande.
- **Statuts de suivi (4 états) :** Reçue → En création → À valider → Livrée.
- **Échanges client/équipe :** commentaires directement dans l'app + notifications WhatsApp.
- **Formats livrés :** PNG/JPG pré-dimensionnés par réseau social, MP4 compressé. Fichiers sources disponibles en option payante.
- **Utilisation en portfolio :** case à cocher explicite à la livraison pour autoriser l'usage de la créa comme exemple.

## Profil de marque

- Enregistré une fois, demandé à la première commande de créa (logo, couleurs, photos).
- Kit identité express payant si le client n'a pas encore de logo.
- Plusieurs profils de marque par compte possibles dès le palier Pro (utile pour les community managers freelances qui gèrent plusieurs clients).

## Authentification et plateforme

- **Connexion :** Google ou code WhatsApp, avec SMS en secours.
- **Plateforme :**
  - Windows : pas d'application desktop installable — un simple accès web responsive par navigateur suffit.
  - Android : application native.
  - iOS : natif, prévu plus tard.

## Paiement et devise

- Mobile Money togolais en priorité (Flooz, T-Money) — pas de prélèvement récurrent fiable disponible, donc rappel mensuel avec renouvellement en un tap. Carte bancaire en second moyen de paiement.
- Agrégateur de paiement à choisir (FedaPay / CinetPay / PayDunya).
- Pas de paiement à la livraison.
- Devise : FCFA au lancement, conversion automatique ensuite pour l'international.

## Langue et vocabulaire

- Français au lancement, anglais prévu à l'international.
- Vocabulaire simplifié à l'écran (le mot "stratégie" reste dans le PDF pro) :
  - "Stratégie" → **Votre plan**
  - "Créa" → **Visuel/Vidéo**
  - "Brief" → **Décrivez ce que vous voulez**
  - "Révision" → **Demander une modification**
  - "Dashboard" → **Mon espace**

## Preuve sociale et notoriété

- Portfolio de 6 à 9 réalisations en avant/après, 3 témoignages avec photo, prénom et activité, aucun chiffre inventé.
- Équipe créative visible : visages, prénoms, rôles.
- Canaux de notoriété envisagés : TikTok, publicité Facebook/Instagram, statuts et groupes WhatsApp, partenariats avec des incubateurs, community managers freelances ambassadeurs, viralité par partage de stratégie et parrainage.
- Jamais de signature de marque Start And Shift sur les créas payantes livrées aux clients.

## Parcours et écrans à designer

**Les 10 écrans initiaux :**
1. Accueil / questionnaire (écran de bienvenue + 10 questions, une par une)
2. Écran de chargement (génération IA, 10-20 sec)
3. Écran résultat stratégie (lecture gratuite, sans compte, double niveau "En clair" / "Détail pro" dépliable, téléchargeable en PDF)
4. Écran de connexion (Google ou WhatsApp)
5. Dashboard principal ("Mon espace" — stratégie sauvegardée + créas en cours/livrées)
6. Écran de demande de créa (choix du type + brief court)
7. Écran suivi de demande (statuts : Reçue → En création → À valider → Livrée)
8. Écran créa livrée (visualisation + téléchargement + bouton révision)
9. Écran abonnement / facturation (Gratuit / Pro / Max)
10. Page "Comment ça marche" (explique le mélange créatifs + IA)

**Écrans ajoutés en cours de cadrage :**
- Page Tarifs (publique, avant connexion)
- Profil de marque
- Paiement
- Notifications
- Parrainage
- Pages légales (mentions légales, CGV, confidentialité)
- États transverses : erreur de génération, paiement échoué, espace vide, perte de connexion
- Pour le natif Android/iOS : demandes de permissions, onboarding premier lancement

**Ordre de conception retenu :** questionnaire → chargement → résultat → connexion (4 premiers écrans en priorité haute fidélité).

**Conservation sans compte :** les réponses et la stratégie restent 7 jours sur l'appareil, avec un rappel de sauvegarde avant expiration.

**Indicateur de succès principal :** le taux de conversion vers un abonnement payant.

## Questionnaire d'onboarding (10 écrans, une question à la fois)

**Écran de bienvenue** (avant la première question) : logo, titre d'accroche, puis 3 étapes courtes — *Répondez* → *Recevez votre stratégie* → *Obtenez vos créas pour publier et vendre*. Bouton : **Commencer**.

1. **Pour qui préparez-vous ce plan ?** — Mon activité / L'activité d'un client
2. **Comment s'appelle l'activité, et que vendez-vous ?** — champ texte court
3. **Dans quel domaine ?** — Mode et beauté / Alimentation / Tech et téléphonie / Services aux pros / Commerce général / Événementiel / Santé et bien-être / Immobilier / Autre
4. **Vos clients et leur zone** (question fusionnée) — Vos clients sont plutôt : Particuliers / Entreprises / Les deux ; puis Où sont-ils : Ma ville / Tout le pays / Plusieurs pays / En ligne, partout
5. **Où vendez-vous aujourd'hui ?** (choix multiple) — WhatsApp / TikTok / Facebook et Marketplace / Instagram / Boutique physique / Site web / Bouche-à-oreille
6. **Qu'est-ce qui vous pousse à agir maintenant ?** — Vendre plus avant une période forte / Je viens de lancer / Mes ventes sont en baisse / Un concurrent progresse plus vite / Rien de précis
7. **Votre priorité pour les 3 prochains mois ?** — Vendre plus / Me faire connaître / Lancer un produit / Fidéliser / Trouver des clients pros
8. **Combien pouvez-vous mettre par mois dans votre communication ?** — Rien pour l'instant / Moins de 25 000 F / 25 000-100 000 F / 100 000-300 000 F / Plus
9. **Combien de temps par semaine pouvez-vous y consacrer ?** — Moins d'1h / 1-3h / Plus de 3h / Quelqu'un s'en occupe
10. **Qu'est-ce qui vous bloque le plus aujourd'hui ?** (choix multiple) — Je ne sais pas quoi publier / Pas le temps / Visuels pas pro / Vues mais peu de ventes / Pas de budget / Déjà essayé sans résultat / Quelqu'un s'en occupe déjà mais je ne suis pas satisfait — suivi d'un champ facultatif : *"Qu'est-ce qui vous rend différent des autres ?"*

## Points encore en attente

- Entité juridique portant l'app (Togo, Maurice, ou autre) — mis de côté pour l'instant.
- Date cible de lancement ou de démo — pas encore d'actualité, le développement doit d'abord avancer.

## Note sur la suite

La conception détaillée écran par écran (mise en page, composants) est reprise par Jean Eudes lui-même dans son outil de design ; ce document sert de référence de cadrage produit, contenu et tarification pour guider ce travail.
